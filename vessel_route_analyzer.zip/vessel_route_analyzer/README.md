# Vessel Route & Threat Analyzer (선박 항로 및 외부 위협 분석 API)

이 프로젝트는 해상 항로 계산 라이브러리인 **`searoute`**와 **`Codex CLI (Google Antigravity)`**의 내장 AI 엔진을 연동하여, 선박의 출발지/경유지/목적지 정보를 바탕으로 최적 항로를 산출하고 경로상의 실시간 위험 이슈(기상, 지정학적 위험, 해적, 정체 등)를 분석하여 최종 ETA(예상 도착 일정)를 보정해주는 도커 기반 백엔드 API 서비스입니다.

본 시스템은 **Linux(Ubuntu)**와 **Windows** 환경 모두에 완벽히 이식되도록 설계되어 있으며, 원클릭 자동 설치 스크립트 및 배치 파일이 탑재되어 있습니다.

---

## 📂 1. 프로젝트 디렉토리 구조

```text
vessel_route_analyzer/
├── Dockerfile                 # 도커 이미지 빌드 명세
├── docker-compose.yml         # 도커 컴포즈 실행 명세 (포트 8000 오픈 및 세션 공유 볼륨 마운트)
├── requirements.txt           # 의존성 패키지 정의 (google-antigravity 등 포함)
├── install_and_run.sh         # Linux(Ubuntu)용 원클릭 자동 설치 및 실행 쉘 스크립트
├── start_service.bat          # Windows용 원클릭 자동 검사 및 가동 배치 파일
├── README.md                  # 본 통합 구축 및 운영 설명서 (본 파일)
└── app/
    ├── main.py                # FastAPI 웹 서버 구동 파일
    ├── config.py              # 설정 파일
    ├── schemas/
    │   └── route.py           # Pydantic 입출력 데이터 규격 정의
    └── services/
        ├── router.py          # searoute 최적 항로 산출 (경유지 연속 연산)
        ├── analyzer.py        # KST(한국시간) 기준의 누적거리 비례 ETA 산출
        └── ai_verifier.py     # google-antigravity SDK 기반의 독자 AI 검증 엔진
```

---

## 📦 2. 도커 이동 방법 (다른 PC로 프로젝트 이식)

본 시스템은 프로젝트 폴더만 압축하여 대상 PC로 전송하면 무설정 이식이 완료됩니다.

### 1단계: 프로젝트 폴더 압축 (현재 PC)
터미널에서 프로젝트 루트 디렉토리 외부로 이동한 뒤, 폴더 전체를 `.tar.gz` 형식으로 압축합니다.
```bash
tar -cvzf vessel_route_analyzer.tar.gz vessel_route_analyzer/
```

### 2단계: 압축 파일 이동 (USB, SSH, SCP 등 활용)
생성된 `vessel_route_analyzer.tar.gz` 파일을 대상 PC로 전송합니다.
```bash
# SCP 예시
scp vessel_route_analyzer.tar.gz user@target-ip:/home/user/
```

### 3단계: 압축 해제 (대상 PC)
대상 PC의 원하는 경로에서 압축을 해제합니다.
```bash
tar -xvzf vessel_route_analyzer.tar.gz
cd vessel_route_analyzer/
```

---

## 🛠️ 3. OS별 자동 설치 및 구동 방법

이식받은 PC의 운영체제(OS)에 맞춰 제공되는 스크립트를 한 번만 실행하면 종속성 설정부터 서버 구동까지 자동으로 진행됩니다.

### A. 🐧 Linux (Ubuntu) 환경
리눅스 서버에서는 패키지 다운로드 및 권한 설정, 서비스 구동을 단 한 줄의 명령어로 자동 실행할 수 있습니다.

```bash
# 권한 부여 후 자동 실행 스크립트 구동
chmod +x install_and_run.sh
./install_and_run.sh
```
* **동작 내용**: 도커 엔진, Docker Compose, Node.js, npm, Codex CLI(`agy`)의 부재 여부를 체크하여 자동 설치하고 백그라운드로 API 서버 컨테이너를 구동합니다.

---

### B. 🪟 Windows 환경
윈도우 PC 환경(명령 프롬프트 또는 PowerShell)에서도 배치 파일 하나로 실행이 가능합니다.

```cmd
:: 1. 프로젝트 폴더 내 start_service.bat 파일을 더블 클릭하여 실행합니다.
start_service.bat
```
* **동작 내용**: Docker Desktop, npm, Codex CLI의 설치 여부를 스스로 검사 및 안내하고 `docker compose up`을 가동합니다.
* **Windows 수동 준비 요소**:
  1. **Docker Desktop for Windows**: [공식 다운로드 링크](https://www.docker.com/products/docker-desktop/)에서 인스턴스를 설치하고 반드시 WSL2 백엔드 통합을 켜두어야 합니다.
  2. **Node.js (npm 포함)**: [공식 다운로드 링크](https://nodejs.org/)에서 Windows용 `.msi` 설치 프로그램을 다운로드해 설치합니다.
  3. **Codex CLI 설치**: 명령 프롬프트(CMD) 또는 PowerShell 창을 열어 아래 명령을 수동 실행해도 됩니다.
     ```cmd
     npm install -g @google/antigravity
     ```

---

## 🔑 4. Codex CLI (Antigravity CLI) 최초 인증 방법

API Key 없이 무제한으로 AI를 연동하기 위해서는, 이식 대상 PC에서도 최초 1회 구글 계정 인증 로그인이 반드시 진행되어야 합니다.

1. 터미널(또는 CMD) 창에 아래 명령을 쳐서 CLI 도구를 최초 가동합니다.
   ```bash
   agy
   ```
2. 대기 메시지에서 **`Enter`** 키를 누르면 브라우저 로그인 창이 자동으로 열립니다.
3. 구글 계정 로그인 후 제공되는 **인증 코드(OAuth 토큰)**를 복사하여 터미널 창에 붙여넣고 엔터를 치면 로그인이 완료됩니다.
4. CLI TUI 창이 로딩되면 정상적으로 로그인이 완료된 것이므로, 단축키 **`Ctrl+D`**를 눌러 종료합니다.

---

## 🔗 5. 컨테이너 연결 구조 및 윈도우 볼륨 대응

본 시스템은 호스트의 Google 자격 증명을 컨테이너와 연결하여 사용합니다. 윈도우와 리눅스의 사용자 홈 디렉토리 경로 체계를 컴포즈 볼륨 마운트가 자동으로 연결하도록 설정되어 있습니다.

* **동작 원리**: 호스트 PC의 구글 인증 키 파일 경로인 `~/.config`와 `~/.gemini` 폴더를 도커 내 `/root/.config` 및 `/root/.gemini`로 읽기 전용 매핑합니다.
* **Windows CMD / PowerShell 대응**: 도커 컴포즈 가동 시 `~` 기호는 Windows 사용자의 홈 경로(`C:\Users\사용자이름`)로 자동 치환되어 Docker Desktop으로 마운트됩니다. 만약 WSL2 환경이 아닌 순수 Windows CMD 환경에서 볼륨 경로 오류가 날 경우, `docker-compose.yml` 파일 내부의 호스트 마운트 경로를 아래처럼 절대 경로로 명시해 주시면 됩니다.
  ```yaml
  volumes:
    - C:\Users\<윈도우사용자계정이름>\.config:/root/.config:ro
    - C:\Users\<윈도우사용자계정이름>\.gemini:/root/.gemini:ro
  ```

---

## 🔌 6. API 사용 설명서 (Frontend 연동 규격)

* **백엔드 API 주소**: `http://localhost:8000/api/analyze-route`
* **자동 생성 API 문서 (Swagger UI)**: `http://localhost:8000/docs`

### **POST** `/api/analyze-route`
선박 정보를 전달받아 최적 항로 좌표와 실시간 위협 정보, 조정된 최종 KST 예상 도착 시간을 반환합니다.

#### **Request Body (Content-Type: application/json)**
```json
{
  "from": "Busan, Korea",
  "stopover": "Shanghai, China",
  "to": "Manila, Philippine",
  "atd": "2026-06-29T22:52:17.566000",
  "eta": "2026-07-06T22:52:17.566000"
}
```
* `stopover`는 선택 입력(Nullable) 필드입니다. 경유지가 없으면 생략하거나 `null`을 넘깁니다.

#### **Response Body (JSON)**
```json
{
  "path": [
    {
      "lat": 35.0,
      "lon": 129.2,
      "arrive_at": "2026-06-29T22:52:17.566000+09:00"
    },
    {
      "lat": 33.940420777777774,
      "lon": 127.088391,
      "arrive_at": "2026-06-30T13:29:05.948040+09:00"
    },
    ...
    {
      "lat": 14.630095,
      "lon": 120.930634,
      "arrive_at": "2026-07-07T10:52:17.566000+09:00"
    }
  ],
  "summary": {
    "delay_risk": "보통 (주의 - Alert)",
    "total_delay_hours": 12,
    "eta_adjusted": "2026-07-07T10:52:17.566000+09:00",
    "issues": [
      {
        "category": "지정학/해적",
        "location": "대만 해협 (Taiwan Strait)",
        "severity": "Medium",
        "description": "양안 긴장으로 실시간 군사 훈련이 잦은 해역입니다. 주의를 요망합니다.",
        "article_link": "https://www.reuters.com/world/asia-pacific/"
      }
    ],
    "analysis_summary": "7월 기상 이슈 및 대만 해협 우회 가능성 등으로 12시간 지연이 가산된 시나리오가 예측되었습니다."
  }
}
```

---

## 💻 7. 클라이언트 호출 예시 코드

### cURL (터미널 즉시 테스트)
```bash
curl -X POST "http://localhost:8000/api/analyze-route" \
     -H "Content-Type: application/json" \
     -d '{
       "from": "Busan, Korea",
       "stopover": "Shanghai, China",
       "to": "Manila, Philippine",
       "atd": "2026-06-29T22:52:17.566000",
       "eta": "2026-07-06T22:52:17.566000"
     }'
```

### JavaScript (Fetch API - Frontend 연동용)
```javascript
const requestData = {
  from: "Busan, Korea",
  stopover: "Shanghai, China",
  to: "Manila, Philippine",
  atd: "2026-06-29T22:52:17.566000",
  eta: "2026-07-06T22:52:17.566000"
};

fetch("http://localhost:8000/api/analyze-route", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(requestData)
})
.then(response => response.json())
.then(data => {
  console.log("KST 좌표별 일정:", data.path);
  console.log("위험 수준:", data.summary.delay_risk);
})
.catch(error => console.error("Error:", error));
```
