@echo off
:: ==============================================================================
:: 선박 최적 항로 및 외부 위협 분석 API - 윈도우(Windows)용 자동 구동 및 기동 배치 파일
:: ==============================================================================
chcp 65001 > nul
setlocal enabledelayedexpansion

echo ====================================================================
echo === 선박 항로 및 위협 분석 API 기동을 시작합니다 (Windows) ===
echo ====================================================================

:: 1. 도커 설치 확인
where docker >nul 2>nul
if %errorlevel% neq 0 (
    echo [경고] Docker가 설치되어 있지 않거나 환경 변수에 등록되지 않았습니다.
    echo Windows 환경에서는 Docker Desktop을 웹 브라우저에서 직접 다운로드하여 설치하셔야 합니다.
    echo 다운로드 링크: https://www.docker.com/products/docker-desktop/
    pause
    exit /b 1
) else (
    echo [확인] Docker가 감지되었습니다.
)

:: 2. Node.js & npm 설치 확인 (CLI 툴 설치용)
where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo [안내] npm이 설치되어 있지 않습니다.
    echo Codex CLI(Antigravity CLI)를 설치하려면 Node.js를 설치하셔야 합니다.
    echo 다운로드 링크: https://nodejs.org/
) else (
    :: 3. Codex CLI 설치 확인
    where agy >nul 2>nul
    if %errorlevel% neq 0 (
        echo [안내] Codex CLI (Antigravity CLI)가 설치되어 있지 않습니다. 설치를 진행합니다.
        npm install -g @google/antigravity
        echo [완료] Codex CLI 설치가 완료되었습니다.
        echo [안내] 'agy' 명령어를 입력하여 최초 브라우저 인증(로그인)을 완료해 주셔야 합니다.
    ) else (
        echo [확인] Codex CLI (Antigravity CLI)가 감지되었습니다.
    )
)

:: 4. 도커 컴포즈 실행
echo [진행] 도커 컨테이너 빌드 및 가동을 시작합니다...
docker compose up --build -d

if %errorlevel% neq 0 (
    echo [에러] 도커 컨테이너 실행에 실패했습니다. Docker Desktop이 활성화되어 있는지 확인해 주세요.
    pause
    exit /b 1
)

echo ====================================================================
echo ★ 서비스가 윈도우 백그라운드로 성공적으로 실행되었습니다!
echo 👉 API 주소: http://localhost:8000/api/analyze-route
echo 👉 API 문서 (Swagger UI): http://localhost:8000/docs
echo ====================================================================
pause
