from pydantic import BaseModel, Field
from typing import List, Optional

class RouteRequest(BaseModel):
    departure_from: str = Field(..., alias="from", description="출발지 (str)")
    stopover: Optional[str] = Field(default=None, description="경유지 (str, nullable)")
    to: str = Field(..., description="목적지 (str)")
    atd: str = Field(..., description="화물 출발 시각 (ISO format, 예: 2026-06-29T22:52:17.566000)")
    eta: str = Field(..., description="도착 예정일 (ISO format)")

    class Config:
        populate_by_name = True # Pydantic v2에서 json 필드명 'from' 호환용 설정

class PathPoint(BaseModel):
    lat: float = Field(..., description="위도 좌표 (double)")
    lon: float = Field(..., description="경도 좌표 (double)")
    arrive_at: str = Field(..., description="한국시각 기준 현재 좌표에 도달하는 예정 시각 (str)")

class IssueItem(BaseModel):
    category: str = Field(..., description="이슈 카테고리 (기상, 지정학/해적, 항구정체, 기타)")
    location: str = Field(..., description="이슈 발생 예상 지역 또는 해역")
    severity: str = Field(..., description="이슈 심각도 (High / Medium / Low)")
    description: str = Field(..., description="이슈 상세 내용 및 선박에 미치는 영향")
    article_link: str = Field(..., description="실제 기사 및 뉴스 출처에 매핑된 구체적인 하위 URL 딥링크")

class SummaryDetails(BaseModel):
    delay_risk: str = Field(..., description="도착 일정 변화 예상 수준 (낮음 (안정) / 보통 (주의 - Alert) / 높음 (경고 - High-Risk))")
    total_delay_hours: int = Field(..., description="예상 총 지연 시간 (시간 단위)")
    eta_adjusted: str = Field(..., description="이슈 및 지연이 반영되어 최종 조정된 예상 도착일정 (한국 시간 KST 기준)")
    issues: List[IssueItem] = Field(..., description="경로상 확인된 실시간 기상/전쟁/기타 이슈 리스트 (실제 기사 딥링크 포함)")
    analysis_summary: str = Field(..., description="AI 경로 검증 분석 종합 소견")

class RouteResponse(BaseModel):
    path: List[PathPoint] = Field(..., description="한국시각 기준 좌표별 도착예정시각을 포함한 10개 항로 리스트")
    summary: SummaryDetails = Field(..., description="이슈 리스트, 지연 지표, AI 종합 소견이 포함된 요약 데이터")
