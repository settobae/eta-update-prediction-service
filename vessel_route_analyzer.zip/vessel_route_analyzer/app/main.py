from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.schemas.route import RouteRequest, RouteResponse, PathPoint, IssueItem, SummaryDetails
from app.services.router import calculate_optimal_route
from app.services.analyzer import analyze_route_issues

app = FastAPI(
    title="선박 최적 항로 및 외부 위협 분석 API",
    description="searoute 라이브러리와 Google Antigravity SDK를 연동하여 해상 최적 항로를 획득하고 실시간 기상/전쟁 등의 지연 위협을 교차 검증합니다.",
    version="3.0.0"
)

# 프론트엔드 연동을 위한 CORS 개방
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {
        "status": "online",
        "service": "Vessel Route & Threat Analyzer Backend",
        "documentation": "/docs"
    }

@app.post("/api/analyze-route", response_model=RouteResponse)
async def analyze_route(request: RouteRequest):
    try:
        # 1. 단일 경유지(stopover)를 감안한 searoute 최적 항로 계산 및 10개 대표 포인트 획득
        sampled_route = calculate_optimal_route(
            departure=request.departure_from,
            destination=request.to,
            stopover=request.stopover
        )
        
        # 2. 자체 검증 AI 모델(Antigravity SDK 비동기 호출)을 통한 경로상 이슈 분석 및 ETA 조정
        analysis_result = await analyze_route_issues(
            departure=request.departure_from,
            destination=request.to,
            atd=request.atd,
            eta=request.eta,
            route_points=sampled_route
        )
        
        # 3. KST 기준으로 계산된 좌표별 경로 데이터(PathPoint) 매핑
        path_points_model = []
        for point in analysis_result.get("route_points", []):
            path_points_model.append(
                PathPoint(
                    lat=point.get("lat"),
                    lon=point.get("lon"),
                    arrive_at=point.get("arrive_at")
                )
            )
        
        # 4. 분석 결과에서 이슈 모델 데이터 포맷팅
        formatted_issues = []
        for issue in analysis_result.get("issues", []):
            formatted_issues.append(
                IssueItem(
                    category=issue.get("category", "기타"),
                    location=issue.get("location", "알 수 없음"),
                    severity=issue.get("severity", "Low"),
                    description=issue.get("description", "상세 내용 없음"),
                    article_link=issue.get("article_link", "")
                )
            )
            
        # 5. 최종 API 응답 요약 데이터(SummaryDetails) 매핑 및 반환
        summary_details = SummaryDetails(
            delay_risk=analysis_result.get("delay_risk", "낮음 (안정)"),
            total_delay_hours=analysis_result.get("total_delay_hours", 0),
            eta_adjusted=analysis_result.get("eta_adjusted", request.eta),
            issues=formatted_issues,
            analysis_summary=analysis_result.get("analysis_summary", "분석이 정상적으로 완료되었습니다.")
        )
        
        response_data = RouteResponse(
            path=path_points_model,
            summary=summary_details
        )
        
        return response_data
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"항로 분석 처리 중 서버 내부 오류가 발생했습니다: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
