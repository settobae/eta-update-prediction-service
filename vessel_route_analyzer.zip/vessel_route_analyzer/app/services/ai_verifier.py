import json
import asyncio
import shutil
import os
import sys
import time
import signal

# Unix 계열에서의 가상 TTY 복제를 위한 pty 임포트
if os.name == 'posix':
    import pty

class AIVerificationEngine:
    """
    로컬 시스템에 설치된 'codex' CLI 명령어를 subprocess 비동기 호출 방식으로 가동하여,
    API Key 요금이나 구글 API 쿼터 한도 없이 분석 결과를 받아오는 AI 자체 검증 엔진 클래스입니다.
    """
    def __init__(self, model_name: str = "gemini-3.5-flash"):
        self.model_name = model_name

    async def verify_route_threats(self, departure: str, destination: str, eta_scheduled: str, route_points: list) -> dict:
        coords_text = "\n".join([f"Point {i+1}: Longitude {p[0]}, Latitude {p[1]}" for i, p in enumerate(route_points)])
        executor_prompt = self._build_executor_prompt(departure, destination, eta_scheduled, coords_text)
        executor_result = await self._run_codex_prompt(executor_prompt, timeout_seconds=90.0)

        reviewer_prompt = self._build_reviewer_prompt(
            departure=departure,
            destination=destination,
            eta_scheduled=eta_scheduled,
            coords_text=coords_text,
            executor_result=executor_result
        )
        return await self._run_codex_prompt(reviewer_prompt, timeout_seconds=90.0)

    def _build_executor_prompt(self, departure: str, destination: str, eta_scheduled: str, coords_text: str) -> str:
        return (
            f"--- 해상 물류 항로 정보 ---\n"
            f"출발지: {departure}\n"
            f"도착지: {destination}\n"
            f"계획된 도착 일정 (ETA): {eta_scheduled}\n\n"
            f"--- 항로상 대표 좌표 10개 (경도, 위도) ---\n"
            f"{coords_text}\n\n"
            f"--- 역할 ---\n"
            f"당신은 해상 물류 위험분석 실행자입니다.\n"
            f"1. 위 10개 좌표 경로 상의 실시간 기상 위협, 지정학/해적 위험, 항구 정체 요소를 조사하십시오.\n"
            f"2. 반드시 검색 도구를 사용해 각 이슈를 뒷받침하는 실제 기사 상세 URL(article_link)을 포함하십시오.\n"
            f"3. 메인 홈페이지 URL, 검색 결과 페이지, 깨진 링크, 좌표와 무관한 링크는 금지입니다.\n"
            f"4. 분석 결과는 검수자가 다시 검사할 예정이므로, 각 이슈 설명과 지연 근거를 구체적으로 적으십시오.\n"
            f"5. 응답은 마크다운 없이 반드시 단일 JSON 객체로만 반환하십시오.\n\n"
            f"최종 반환 JSON 규격:\n"
            f"{{\n"
            f"  \"issues\": [\n"
            f"    {{\n"
            f"      \"category\": \"기상 | 지정학/해적 | 항구정체 | 기타 중 택일\",\n"
            f"      \"location\": \"이슈 발생 해역/지역 명칭\",\n"
            f"      \"severity\": \"High | Medium | Low\",\n"
            f"      \"description\": \"구체적인 기상 또는 보안 위협 설명\",\n"
            f"      \"article_link\": \"실시간 검색으로 취득한 실제 뉴스 기사 개별 상세 URL\",\n"
            f"      \"publisher\": \"기사 발행 매체명\",\n"
            f"      \"published_at\": \"기사 발행 시각 또는 날짜\",\n"
            f"      \"source_tier\": \"Tier 1 | Tier 2 | Tier 3 | Tier 4\",\n"
            f"      \"verification_status\": \"verified\"\n"
            f"    }}\n"
            f"  ],\n"
            f"  \"delay_risk\": \"낮음 (안정) | 보통 (주의 - Alert) | 높음 (경고 - High-Risk) 중 하나 선택\",\n"
            f"  \"total_delay_hours\": 예상되는 총 지연 시간 (정수값),\n"
            f"  \"analysis_summary\": \"실행자 관점의 종합 소견 및 지연 근거\"\n"
            f"}}"
        )

    def _build_reviewer_prompt(
        self,
        departure: str,
        destination: str,
        eta_scheduled: str,
        coords_text: str,
        executor_result: dict
    ) -> str:
        executor_json = json.dumps(executor_result, ensure_ascii=False, indent=2)
        return (
            f"--- 해상 물류 항로 정보 ---\n"
            f"출발지: {departure}\n"
            f"도착지: {destination}\n"
            f"계획된 도착 일정 (ETA): {eta_scheduled}\n\n"
            f"--- 항로상 대표 좌표 10개 (경도, 위도) ---\n"
            f"{coords_text}\n\n"
            f"--- 실행자 초안 ---\n"
            f"{executor_json}\n\n"
            f"--- 역할 ---\n"
            f"당신은 해상 물류 위험분석 검수자입니다.\n"
            f"1. 실행자 초안의 각 기사 링크가 실제 기사 상세 URL인지, 메인 도메인/오류 링크/무관 링크는 아닌지 검토하십시오.\n"
            f"2. 인근 국가의 주요 방송사/신문사와 국제적으로 널리 알려진 방송사/신문사 기사를 우선적으로 채택하십시오.\n"
            f"3. 각 이슈가 항로 좌표와 관련 있는지, 설명과 지연 추정이 과장되거나 틀린 부분이 없는지 검토하십시오.\n"
            f"4. 필요하면 이슈를 수정, 삭제, 보완하고 총 지연시간과 위험등급을 다시 산정하십시오.\n"
            f"5. source_tier는 다음 기준을 따르십시오: Tier 1=국제 주요 매체, Tier 2=인근국 주요 매체, Tier 3=정부/항만/기상 공식기관, Tier 4=기타.\n"
            f"6. verification_status는 검수 후 그대로 유지하면 verified, 내용이나 링크를 보정했으면 corrected, 출처가 부적합하면 rejected_reference로 표시하십시오.\n"
            f"7. 검수 결과는 마크다운 없이 반드시 아래 JSON 형식으로만 반환하십시오.\n\n"
            f"최종 반환 JSON 규격:\n"
            f"{{\n"
            f"  \"issues\": [\n"
            f"    {{\n"
            f"      \"category\": \"기상 | 지정학/해적 | 항구정체 | 기타 중 택일\",\n"
            f"      \"location\": \"이슈 발생 해역/지역 명칭\",\n"
            f"      \"severity\": \"High | Medium | Low\",\n"
            f"      \"description\": \"검수 후 확정된 위협 설명\",\n"
            f"      \"article_link\": \"검수 후 유지한 실제 뉴스 기사 상세 URL\",\n"
            f"      \"publisher\": \"기사 발행 매체명\",\n"
            f"      \"published_at\": \"기사 발행 시각 또는 날짜\",\n"
            f"      \"source_tier\": \"Tier 1 | Tier 2 | Tier 3 | Tier 4\",\n"
            f"      \"verification_status\": \"verified | corrected | rejected_reference\"\n"
            f"    }}\n"
            f"  ],\n"
            f"  \"delay_risk\": \"낮음 (안정) | 보통 (주의 - Alert) | 높음 (경고 - High-Risk) 중 하나 선택\",\n"
            f"  \"total_delay_hours\": 예상되는 총 지연 시간 (정수값),\n"
            f"  \"analysis_summary\": \"검수자가 확정한 최종 종합 소견 및 정정 사항\"\n"
            f"}}"
        )

    async def _run_codex_prompt(self, prompt: str, timeout_seconds: float = 45.0) -> dict:
        """
        로컬 'codex' CLI에 프롬프트를 전달하되,
        가상 TTY(pty) 상에서 표준 입력(stdin)으로 데이터를 쓰고 Ctrl+D(EOF) 제어 문자를 인입하여
        TTY 격리 문제를 우회합니다.
        """
        # 시스템 PATH에서 'codex' 명령어 위치 확인
        codex_executable = shutil.which("codex")
        if not codex_executable:
            codex_executable = "codex"

        try:
            # Unix 환경(Linux)일 경우 pty.fork()를 사용하여 가상 터미널 환경을 통째로 자식 프로세스에 상속합니다.
            if os.name == 'posix':
                pid, fd = pty.fork()
                
                if pid == 0:
                    # 자식 프로세스: 가상 TTY가 장착되어 stdin이 실제 터미널로 인식되는 상태에서 codex 기동
                    try:
                        # 인자 없이 기동하여 표준 입력으로부터 데이터를 정상적으로 대기하게 만듭니다.
                        os.execvp(codex_executable, [codex_executable])
                    except Exception as child_err:
                        sys.stderr.write(f"자식 프로세스 실행 실패: {child_err}")
                        sys.exit(1)
                else:
                    # 부모 프로세스: 마스터 TTY fd에 프롬프트를 흘려보내고 TTY EOF 문자(\x04 = Ctrl+D)를 보내 입력을 매듭짓습니다.
                    os.set_blocking(fd, False)
                    
                    # 1. 가상 터미널 마스터로 프롬프트 텍스트 전달
                    os.write(fd, prompt.encode("utf-8"))
                    # 2. 줄바꿈 및 터미널 EOF(Ctrl+D) 전송하여 입력 끝맺음
                    os.write(fd, b"\n\x04")
                    
                    output_bytes = bytearray()
                    start_time = time.time()
                    
                    # 자식 프로세스 출력을 대기하며 계속 읽어들임
                    while True:
                        # [안전장치 1] 타임아웃 발생 시 자식을 강제 킬하고 안전 모드로 복구합니다.
                        if time.time() - start_time > timeout_seconds:
                            try:
                                os.kill(pid, signal.SIGKILL)
                                os.waitpid(pid, 0) # 좀비 프로세스 정리
                            except:
                                pass
                            raise TimeoutError("Codex CLI 분석 시간이 초과되었습니다 (최대 45초 제한).")

                        # [안전장치 2] 자식 프로세스 완료 여부 수시 점검 (무한 행 방지)
                        try:
                            finished_pid, status = os.waitpid(pid, os.WNOHANG)
                            if finished_pid == pid:
                                # 자식이 끝났으면, 마지막 남은 TTY 출력 버퍼를 한 번 더 비우고 루프 탈출
                                try:
                                    while True:
                                        data = os.read(fd, 4096)
                                        if not data:
                                            break
                                        output_bytes.extend(data)
                                except:
                                    pass
                                break
                        except ChildProcessError:
                            # 자식 프로세스 청소가 완료된 경우
                            break

                        # [안전장치 3] 논블로킹 데이터 스트림 읽기
                        try:
                            data = os.read(fd, 4096)
                            if not data:
                                break
                            output_bytes.extend(data)
                        except BlockingIOError:
                            # 데이터가 아직 없으면 CPU 점유를 막기 위해 양보하고 대기
                            await asyncio.sleep(0.1)
                        except OSError:
                            # 가상 TTY가 파괴되었을 때
                            break
                    
                    try:
                        os.close(fd)
                    except:
                        pass
                    
                    output_text = output_bytes.decode("utf-8", errors="ignore")
            else:
                # Windows 환경 등 (인자 방식으로 Fallback 기동)
                process = await asyncio.create_subprocess_exec(
                    codex_executable,
                    "--",
                    prompt,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await process.communicate()
                
                if process.returncode != 0:
                    err_msg = stderr.decode("utf-8", errors="ignore")
                    raise RuntimeError(f"Codex CLI 에러 (반환코드 {process.returncode}): {err_msg}")
                    
                output_text = stdout.decode("utf-8", errors="ignore")
            
            # JSON 추출 및 파싱
            clean_json = output_text.strip()
            
            # TUI 출력 노이즈 전처리
            start_idx = clean_json.find("{")
            end_idx = clean_json.rfind("}")
            if start_idx != -1 and end_idx != -1:
                clean_json = clean_json[start_idx:end_idx+1]
            
            print("==================== DEBUG: CODEX OUTPUT ====================")
            print(clean_json)
            print("=============================================================")
                
            return json.loads(clean_json)

        except Exception as e:
            raise RuntimeError(f"로컬 'codex' CLI 호출 실패: {e}")
