import json
import asyncio
from google.antigravity import Agent, LocalAgentConfig

class AIVerificationEngine:
    """
    Antigravity SDK (google-antigravity)를 사용하여 API Key 없이 
    사용자의 Google 계정 세션 크레딧으로 해상 위협 및 실시간 뉴스를 검증하는 AI 엔진 클래스입니다.
    """
    def __init__(self, model_name: str = "gemini-3.5-flash"):
        self.model_name = model_name

    async def verify_route_threats(self, departure: str, destination: str, eta_scheduled: str, route_points: list) -> dict:
        """
        10개의 위경도 좌표 포인트 정보를 바탕으로 경로상의 기상/전쟁 이슈를 분석합니다.
        (Antigravity CLI의 실시간 인터넷 검색/그라운딩 및 도구를 활용합니다.)
        """
        coords_text = "\n".join([f"Point {i+1}: Longitude {p[0]}, Latitude {p[1]}" for i, p in enumerate(route_points)])

        system_instruction = (
            "당신은 전 세계의 해상 항로 안전 및 물류 지연 요소를 실시간으로 모니터링하고 분석하는 '해상 위험 관리 및 선박 물류 분석 전문가'입니다.\n"
            "주어진 10개의 위경도 좌표 항로를 보고, 해당 지역에서 발생하고 있는 실시간 기상 이슈(태풍, 몬순, 폭풍 등), "
            "지정학적 갈등/전쟁/해적 위협(홍해 사태, 호르무즈 해협 긴장, 해적 다발 구역 등), 항구 정체 등의 이슈가 항로 및 최종 도착 일정에 미칠 영향을 철저하게 검증하십시오."
        )

        prompt = (
            f"--- 항로 정보 ---\n"
            f"출발지: {departure}\n"
            f"도착지: {destination}\n"
            f"계획된 도착 일정 (ETA): {eta_scheduled}\n\n"
            f"--- 항로상 대표 좌표 10개 (경도, 위도) ---\n"
            f"{coords_text}\n\n"
            f"--- 분석 요청 사항 ---\n"
            f"1. 위 10개 좌표 경로 상의 실시간 기상 위협, 전쟁/분쟁/지정학 위험, 해협 병목 및 항구 정체 이슈를 분석해 주세요.\n"
            f"2. [실제 개별 기사 딥링크 제공 필수]: 각 이슈의 'article_link' 필드에는 메인 페이지 주소(예: https://www.reuters.com)를 절대 작성하지 마십시오. "
            f"인터넷 실시간 검색 도구를 사용하여 실제 실존하는 상세 기사 주소, 해양기상 보고서 딥링크 URL을 매핑하여 기재해야 합니다.\n"
            f"3. [지연 위험 등급의 물류 비즈니스화]: 지연 시간 및 우회 가능성에 근거하여 비즈니스 영향도를 판단하고 지연 위험 수준을 아래의 3단계로 엄격히 분류하십시오.\n"
            f"   - '낮음 (안정)' : 지연이 없거나 미미하여 스케줄 변동 가능성이 거의 없음.\n"
            f"   - '보통 (주의 - Alert)' : 생산 스케줄 및 현장 하역 일정의 사전 대응이 필요한 지연 변수가 감지됨.\n"
            f"   - '높음 (경고 - High-Risk)' : 심각한 우회 항로 선택(예: 희망봉 우회) 또는 항만 마비 등으로 전반적인 스케줄 재조정이 불가피함.\n\n"
            f"반드시 아래 JSON 형식으로만 완벽한 JSON 오브젝트를 반환해 주세요. 다른 텍스트는 출력하지 마십시오.\n"
            f"JSON 포맷 규격:\n"
            f"{{\n"
            f"  \"issues\": [\n"
            f"    {{\n"
            f"      \"category\": \"기상 | 지정학/해적 | 항구정체 | 기타 중 택일\",\n"
            f"      \"location\": \"이슈가 예상되는 해역 또는 지역 명칭\",\n"
            f"      \"severity\": \"High | Medium | Low\",\n"
            f"      \"description\": \"구체적인 이슈 현황 및 선박 항해 지연 유발 이유\",\n"
            f"      \"article_link\": \"실시간 취득한 실제 해당 뉴스 기사의 개별 하위 상세 URL\"\n"
            f"    }}\n"
            f"  ],\n"
            f"  \"delay_risk\": \"낮음 (안정) | 보통 (주의 - Alert) | 높음 (경고 - High-Risk) 중 하나 선택\",\n"
            f"  \"total_delay_hours\": 예상되는 총 지연 시간 (정수값, 지연이 전혀 없으면 0),\n"
            f"  \"analysis_summary\": \"AI 경로 검증 결과에 대한 종합 소견 및 권장 대처 방안\"\n"
            f"}}"
        )

        # Antigravity CLI 에이전트 인스턴스 생성 및 비동기 호출
        config = LocalAgentConfig(
            system_instructions=system_instruction,
            model=self.model_name
        )

        async with Agent(config) as agent:
            response = await agent.chat(prompt)
            full_text = ""
            async for token in response:
                full_text += token

        # JSON 파싱 전처리 (마크다운 코드블록 제거)
        clean_json = full_text.strip()
        if "```json" in clean_json:
            clean_json = clean_json.split("```json")[1].split("```")[0].strip()
        elif "```" in clean_json:
            clean_json = clean_json.split("```")[1].split("```")[0].strip()

        return json.loads(clean_json)
