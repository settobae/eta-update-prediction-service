import json
import searoute as sr
from google import genai
from google.genai import types
from app.config import config

# 주요 항구 캐시 (API 호출 횟수 감소 및 Fallback용)
PORT_COORDINATES_CACHE = {
    "busan": [129.07, 35.17],
    "rotterdam": [4.47, 51.92],
    "singapore": [103.85, 1.29],
    "shanghai": [121.47, 31.23],
    "suez": [32.55, 29.97],
    "los angeles": [-118.24, 33.74],
    "la": [-118.24, 33.74],
    "panama": [-79.91, 9.11],
    "new york": [-74.00, 40.71],
    "gibraltar": [-5.35, 36.14],
    "hamburg": [9.99, 53.55],
    "tokyo": [139.69, 35.67],
    "yokohama": [139.64, 35.44],
    "port said": [32.30, 31.26],
    "manila": [120.98, 14.59]
}

def get_coordinates_from_name(name: str) -> list:
    """
    항구 또는 도시 명칭을 바탕으로 위경도 [경도(lon), 위도(lat)]를 반환합니다.
    캐시에 없으면 Gemini 3.5 API를 사용해 좌표를 추론합니다.
    """
    clean_name = name.strip().lower()
    
    # 1. 캐시 조회 (완전 일치 우선)
    for port, coords in PORT_COORDINATES_CACHE.items():
        if clean_name == port:
            return coords

    # 2. 캐시 조회 (부분 일치 - 단, 'la' 오매핑 방지를 위해 캐시 키가 3글자 이상인 경우만 허용)
    for port, coords in PORT_COORDINATES_CACHE.items():
        if len(port) >= 3 and port in clean_name:
            return coords

    # 3. 캐시에 없으면 Gemini 3.5 API로 조회
    if not config.GEMINI_API_KEY:
        raise ValueError("GEMINI_API_KEY가 설정되지 않아 좌표 추론을 진행할 수 없습니다.")
        
    client = genai.Client(api_key=config.GEMINI_API_KEY)
    model_name = config.GEMINI_MODEL_NAME
    
    prompt = (
        f"항구 또는 도시 명칭 '{name}'의 대표적인 항구 중심부 위경도 좌표를 알려주세요.\n"
        f"반드시 아래 JSON 형식으로만 응답해야 합니다. 다른 설명 텍스트는 일체 생략하세요.\n"
        f"JSON 형식:\n"
        f"{{\n"
        f"  \"longitude\": 경도값(float),\n"
        f"  \"latitude\": 위도값(float)\n"
        f"}}"
    )
    
    try:
        response = client.models.generate_content(
            model=model_name,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type="application/json"
            )
        )
        data = json.loads(response.text)
        return [float(data["longitude"]), float(data["latitude"])]
    except Exception as e:
        print(f"⚠ Gemini 좌표 추론 실패 ({e}), 기본값 [0.0, 0.0]을 반환합니다.")
        return [0.0, 0.0]

def interpolate_coords(coords: list, target_count: int = 10) -> list:
    """
    위경도 좌표 리스트를 받아 수학적 선형 보간을 수행하여 정확히 target_count(10)개의 좌표 리스트로 축약합니다.
    """
    n = len(coords)
    if n == 0:
        return [[0.0, 0.0]] * target_count
    if n == 1:
        return [coords[0]] * target_count
        
    sampled = []
    for i in range(target_count):
        float_idx = i * (n - 1) / (target_count - 1)
        lower_idx = int(float_idx)
        upper_idx = min(lower_idx + 1, n - 1)
        weight = float_idx - lower_idx
        
        lon = coords[lower_idx][0] * (1 - weight) + coords[upper_idx][0] * weight
        lat = coords[lower_idx][1] * (1 - weight) + coords[upper_idx][1] * weight
        sampled.append([lon, lat])
        
    return sampled

def calculate_optimal_route(departure: str, destination: str, stopover: str = None) -> list:
    """
    출발지, 단일 경유지(stopover, 선택), 도착지를 엮어 해상 최적 항로를 계산하고,
    전체 항로 좌표를 취합하여 최종 10개의 좌표 포인트로 보간 및 축약합니다.
    """
    # 1. 경로 순서 설정 (출발지 -> 경유지(존재 시) -> 도착지)
    waypoints = [stopover] if stopover and stopover.strip() else []
    locations = [departure] + waypoints + [destination]
    
    # 2. 모든 지점의 좌표 변환
    coords_list = []
    for loc in locations:
        coords = get_coordinates_from_name(loc)
        coords_list.append(coords)
        
    # 3. 세그먼트별 해상 항로 계산 및 병합
    full_route_coordinates = []
    for i in range(len(coords_list) - 1):
        segment_origin = coords_list[i]
        segment_dest = coords_list[i+1]
        
        print(f"⚓ 세그먼트 {i+1} 계산: {locations[i]} {segment_origin} ➡️ {locations[i+1]} {segment_dest}")
        
        segment_route = sr.searoute(segment_origin, segment_dest)
        segment_coords = segment_route['geometry']['coordinates']
        
        if full_route_coordinates and segment_coords:
            full_route_coordinates.extend(segment_coords[1:])
        else:
            full_route_coordinates.extend(segment_coords)
            
    # 4. 전체 항로를 정확히 10개 대표 좌표로 축약
    simplified_route = interpolate_coords(full_route_coordinates, target_count=10)
    
    return simplified_route
