import os
import math
import asyncio
from datetime import datetime, timedelta, timezone
from app.config import config
from app.services.ai_verifier import AIVerificationEngine

def haversine_distance(p1: list, p2: list) -> float:
    """
    두 지점(p = [lon, lat]) 간의 대원 거리(Great-Circle Distance)를 Haversine 공식으로 구합니다 (단위: km).
    """
    lon1, lat1 = math.radians(p1[0]), math.radians(p1[1])
    lon2, lat2 = math.radians(p2[0]), math.radians(p2[1])
    
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    r = 6371.0
    return c * r

def parse_to_kst(time_str: str) -> datetime:
    """
    Naive 또는 UTC ISO 타임 스트링을 파싱하여 한국 시간(KST, UTC+9) datetime 객체로 변환합니다.
    """
    kst_tz = timezone(timedelta(hours=9))
    if time_str.endswith("Z"):
        return datetime.fromisoformat(time_str[:-1]).replace(tzinfo=timezone.utc).astimezone(kst_tz)
    
    dt = datetime.fromisoformat(time_str)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=kst_tz)
    return dt.astimezone(kst_tz)

def calculate_points_eta(atd: str, eta: str, route_points: list, delay_hours: int) -> list:
    """
    출발 시각(atd)과 계획된 도착 시각(eta)을 기준으로 지연 시간(delay_hours)을 가산한 후,
    10개 좌표 간의 누적 해상 거리에 비례하여 각 좌표의 KST 도착 예정 시각(arrive_at)을 계산합니다.
    """
    n = len(route_points)
    if n == 0:
        return []

    # 1. 구간별 해상 거리 및 누적 거리 계산
    distances = [0.0]
    for i in range(1, n):
        dist = haversine_distance(route_points[i-1], route_points[i])
        distances.append(distances[-1] + dist)
    
    total_distance = distances[-1]
    
    # 2. 타임존(KST)이 반영된 출발 시각(atd) 및 계획 도착 시각(eta) 파싱
    atd_dt = parse_to_kst(atd)
    eta_dt = parse_to_kst(eta)

    # 3. 지연 시간이 가산된 최종 조정 도착 시각 (KST)
    adjusted_dt = eta_dt + timedelta(hours=delay_hours)
    
    # 총 운항 소요 시간
    total_travel_time = adjusted_dt - atd_dt

    # 4. 거리 비율에 맞추어 각 좌표별 도달 예정시간(arrive_at) 계산
    points_with_eta = []
    for i in range(n):
        ratio = (distances[i] / total_distance) if total_distance > 0 else 0
        point_eta_dt = atd_dt + (total_travel_time * ratio)
        
        points_with_eta.append({
            "lat": route_points[i][1],
            "lon": route_points[i][0],
            "arrive_at": point_eta_dt.isoformat()
        })
        
    return points_with_eta

async def analyze_route_issues(departure: str, destination: str, atd: str, eta: str, route_points: list) -> dict:
    """
    AIVerificationEngine을 호출하여 경로상 위협을 검증하고, 
    각 좌표별 한국 시간(KST) 도착 시각(arrive_at) 연산을 가산 처리하는 상위 통합 서비스 비동기 함수입니다.
    """
    engine = AIVerificationEngine(
        model_name=config.GEMINI_MODEL_NAME
    )
    
    print("🤖 [진행] Codex CLI 실행자/검수자 파이프라인 구동 중...")
    
    # AI 검증 수행 (예외 발생 대비 try-except)
    try:
        raw_result = await engine.verify_route_threats(
            departure=departure,
            destination=destination,
            eta_scheduled=eta,
            route_points=route_points
        )
        print("✔ [완료] Codex CLI 실행자/검수자 검증 완료")
    except Exception as e:
        print(f"❌ Codex AI 분석 에러 (AIVerificationEngine 실패): {e}")
        raw_result = {
            "issues": [
                {
                    "category": "시스템 정보",
                    "location": "전체 경로",
                    "severity": "Low",
                    "description": "Codex CLI 실행자/검수자 파이프라인 호출 실패로 안전 시뮬레이션 모드로 전환되었습니다.",
                    "article_link": "https://platform.openai.com/",
                    "publisher": "OpenAI",
                    "published_at": "",
                    "source_tier": "Tier 4",
                    "verification_status": "corrected"
                }
            ],
            "delay_risk": "보통 (주의 - Alert)",
            "total_delay_hours": 12,
            "analysis_summary": "Codex CLI 기반 위험 분석이 실패하여 12시간 지연을 가정한 보수적 fallback 결과를 반환했습니다."
        }
    
    # KST 비례배분 예정 시각 산출 진행 로그 출력
    print(f"⏱️ [진행] 화물 출발 시각({atd}) 및 도착예정 시각({eta}) 기준, 10개 좌표별 KST 비례배분 도달 일정 산출 동작 중...")
    
    # 지연 시간 및 KST 타임존 기반 각 포인트별 예정 시각 산출 (atd와 eta 기준 비례배분)
    delay_hours = int(raw_result.get("total_delay_hours", 0))
    points_with_eta = calculate_points_eta(atd, eta, route_points, delay_hours)
    
    # 최종 조정 도착 일정 계산 (KST)
    eta_dt = parse_to_kst(eta)
    adjusted_dt = eta_dt + timedelta(hours=delay_hours)
    
    raw_result["eta_adjusted"] = adjusted_dt.isoformat()
    raw_result["route_points"] = points_with_eta
    
    print(f"✔ [완료] 선박 항로 및 외부 위협 종합 분석 파이프라인 최종 완료 (정상 동작 중)")
    
    return raw_result
