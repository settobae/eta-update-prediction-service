import os
from dotenv import load_dotenv

# .env 파일이 존재할 경우 로드
load_dotenv()

class Config:
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AQ.Ab8RN6K6ey02A__KMCuSZw2og0NHsYBeHgMHUGyDAhqLcCWw9A")
    GEMINI_MODEL_NAME = os.getenv("GEMINI_MODEL_NAME", "gemini-3.5-flash")
    
config = Config()
