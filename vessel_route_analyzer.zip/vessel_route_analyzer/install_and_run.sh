#!/bin/bash

# ==============================================================================
# 선박 최적 항로 및 외부 위협 분석 API - 리눅스(Ubuntu)용 자동 설치 및 구동 스크립트
# ==============================================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== 선박 항로 및 위협 분석 API 설치 및 구동을 시작합니다 (Linux) ===${NC}"

# 1. 도커 설치 확인 및 설치
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}[안내] Docker가 설치되어 있지 않습니다. Docker Engine 설치를 진행합니다...${NC}"
    sudo apt-get update
    sudo apt-get install -y apt-transport-https ca-certificates curl gnupg lsb-release
    
    sudo mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
      $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
      
    sudo apt-get update
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    
    echo -e "${YELLOW}[안내] 일반 사용자 계정($USER)에 도커 실행 권한을 등록합니다...${NC}"
    sudo usermod -aG docker $USER
    echo -e "${GREEN}[완료] Docker 설치 및 권한 등록이 완료되었습니다.${NC}"
else
    echo -e "${GREEN}[확인] Docker가 이미 설치되어 있습니다.${NC}"
fi

# 2. Node.js 및 npm 확인
if ! command -v npm &> /dev/null; then
    echo -e "${YELLOW}[안내] Node.js & npm이 설치되어 있지 않습니다. 설치를 시작합니다...${NC}"
    sudo apt-get update
    sudo apt-get install -y nodejs npm
    echo -e "${GREEN}[완료] Node.js 및 npm 설치가 완료되었습니다.${NC}"
fi

# 3. Codex CLI (Antigravity CLI) 설치 확인 및 안내
if ! command -v agy &> /dev/null; then
    echo -e "${YELLOW}[안내] Codex CLI (Antigravity CLI)가 설치되어 있지 않습니다. 글로벌 설치를 시작합니다...${NC}"
    sudo npm install -g @google/antigravity
    echo -e "${GREEN}[완료] Codex CLI 설치가 완료되었습니다.${NC}"
    
    echo -e "${YELLOW}================================================================${NC}"
    echo -e "${YELLOW}[필수 작업] AI 세션 연동을 위한 구글 로그인이 필요합니다.${NC}"
    echo -e "${YELLOW}아래의 지침에 따라 인증을 완료해 주십시오:${NC}"
    echo -e "${YELLOW}1. 터미널에 'agy'를 입력하여 프로그램을 최초 실행합니다.${NC}"
    echo -e "${YELLOW}2. 엔터키를 눌러 브라우저 로그인 창을 띄웁니다.${NC}"
    echo -e "${YELLOW}3. 구글 계정 로그인 후 발급되는 토큰 코드를 복사하여 터미널 창에 붙여넣습니다.${NC}"
    echo -e "${YELLOW}================================================================${NC}"
    
    read -p "구글 로그인을 지금 진행하시겠습니까? (y/n) " choice
    if [ "$choice" = "y" ] || [ "$choice" = "Y" ]; then
        agy || true
    else
        echo -e "${RED}[주의] 로그인이 완료되지 않으면 API 구동 시 AI 팩트체크 분석 기능이 동작하지 않습니다.${NC}"
    fi
else
    echo -e "${GREEN}[확인] Codex CLI (Antigravity CLI)가 설치되어 있습니다.${NC}"
fi

# 4. 도커 컨테이너 빌드 및 백그라운드 구동
echo -e "${GREEN}=== 백엔드 API 컨테이너 가동을 시작합니다 ===${NC}"
sudo docker compose up --build -d

echo -e "${GREEN}================================================================${NC}"
echo -e "${GREEN}★ 선박 최적 항로 및 위협 분석 API 서비스가 백그라운드로 성공적으로 실행되었습니다!${NC}"
echo -e "${GREEN}👉 API 주소: http://localhost:8000/api/analyze-route${NC}"
echo -e "${GREEN}👉 API 대화형 문서 (Swagger UI): http://localhost:8000/docs${NC}"
echo -e "${GREEN}================================================================${NC}"
